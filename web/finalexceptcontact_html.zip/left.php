<html>
<head>
<title>left</title>
</head>
<body>
<form target="log" method="post" action="login.php">
<div class="myform"> 
<input type="submit" value="Place Order" name="place"/ autofocus><br><br>
<input type="submit" value="Order history" name="history"/><br><br>
<input type="submit" value="Edit Details" name="edit"/><br><br>
<input type="submit" value="Logout" name="logout"/><br><br>
</div>
</form>
<style>
body{
background-color: #DDEEDD;
margin-top:40px;
}
.myform input{
	background-color:#DDEEDD;
	border:0px;
	font-size:22px;
}
.myform input:hover{
	background-color:#4CAF50;
}
.myform input:focus{
	background-color:#4CAF50;
	text-color:white;
}
</style>
</body>
</html>