<?php
session_start();
if(!isset($_SESSION['loginuser']))
	header("Location:loginpage.php");
?>
<html>
<head>
<title>login page</title>
</head>
<body>
<iframe width="100%" height="15%" src="top.html" frameBorder="no"></iframe>
<iframe id="frame1" width="15%" height="85%" src="left.php" frameBorder="no"></iframe>
<iframe id="js_frame" onload="populateiframe();" width="84.5%" height="85%" src="login.php" name="log" frameBorder="no" ></iframe>
</body>
</html>
<style>
document.getElementById('frame1').focus();
</style>
<style>
body,html
{
    background-color:#DDEEDD;
    padding:0px;
    margin:0px;
    height:100%;
    width:100%;
    overflow:hidden;
}
</style>