<?php
$herr = $werr = $terr = "";
if(isset($_POST['submit2']))
{
		if (!filter_var($_POST['height'], FILTER_VALIDATE_FLOAT))
		$herr="not valid";
	if (!filter_var($_POST['weight'], FILTER_VALIDATE_FLOAT))
		$werr="not valid";
	if (!filter_var($_POST['target'], FILTER_VALIDATE_FLOAT))
		$terr="not valid";
	if(empty($_POST['height']))
		$herr="required";
	if(empty($_POST['weight']))
		$werr="required";
	if(empty($_POST['target']))
		$terr="required";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>BMI</title>
  <meta charset="utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="height:1500px">
<link href='http://fonts.googleapis.com/css?family=Ubuntu:bold' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Vollkorn' rel='stylesheet' type='text/css'>

<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <!--<div class="navbar-header">
      <a class="navbar-brand" class="dropdown" href="#"><span class="glyphicon glyphicon-list fa-5x" style="font-size:1.6em;" style="color:#512da8"></span> </a>
    </div>--!>
    <ul class="nav navbar-nav">
      <li class="active" class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-list fa-5x" style="font-size:1.6em;" style="color:#512da8"></span> <span class="caret"></span></a>
        <ul class="dropdown-menu">
        <li class="dropdown-submenu"><a class="dropdown-toggle" href="#">About Us<span class="caret"></span></a>
	<ul class="dropdown-menu">
	<li><a href="prac2.html#who">Who Are We</a></li>
	<li><a href="prac2.html#what">What Do We Do</a></li>
          <li><a href="prac2.html#our">Our Stories</a></li>
	</ul></li>
          <li><a href="Achievement.html">Achievements</a></li>
	<li><a href="#">Check BMI</a></li>
        </ul>
      </li>
<li><a href="prac2.html"><span class="glyphicon glyphicon-home fa-5x" style="font-size:2em;" style="color:#512da8"></span></a></li>
      <li><a href="Client_new.php">Clients</a></li>
      <li><a href="Career_new.html">Careers</a></li>
	<li><a href="Subscribe_new.php">Subscribe</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
	<li><a href="contact.html">Contact Us</a></li>
      <li><a href="Client_new.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="loginpage.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
  
<div class="container">
  
</div>

<script>
 $(document).ready(function(){
  $(window).scroll(function() { 
    if ($(document).scrollTop() > 550) { 
      $('.navbar').addClass('shrink'); 
    } else { 
      $('.navbar').removeClass('shrink'); 
    } 
  }); 
 });
</script>

<style>

body{
background-color: #F6F6EA;
}

.dropdown-submenu {
    position: relative;
}

.dropdown-submenu>.dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -6px;
    margin-left: -1px;
    -webkit-border-radius: 0 6px 6px 6px;
    -moz-border-radius: 0 6px 6px;
    border-radius: 0 6px 6px 6px;
}

.dropdown-submenu:hover>.dropdown-menu {
    display: block;
}

.dropdown-submenu>a:after {
    display: block;
    content: " ";
    float: right;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
    border-width: 5px 0 5px 5px;
    border-left-color: #ccc;
    margin-top: 5px;
    margin-right: -10px;
}

.dropdown-submenu:hover>a:after {
    border-left-color: #fff;
}

.dropdown-submenu.pull-left {
    float: none;
}

.dropdown-submenu.pull-left>.dropdown-menu {
    left: -100%;
    margin-left: 10px;
    -webkit-border-radius: 6px 0 6px 6px;
    -moz-border-radius: 6px 0 6px 6px;
    border-radius: 6px 0 6px 6px;
}


.navbar.shrink{ 
   background: #0F9A19 
}

.navbar {
   background-color: blue;
   
   border-color: transparent;
}


.navbar-default {
    background-color: grey;

opacity:0.7;
    border-color: grey;
}
.navbar-default .navbar-nav > li > a {
    color: white;
}
.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {
    background-color: purple;opacity:0.65;
    color: white;
}

</style>
<style>
.logo{
width:200px;
 margin-left: 57px;

margin-top:-70px;
}
</style>

<style>
.container-1{
  width: 430px;
  vertical-align: middle;
  white-space: nowrap;
  position: relative;
	float:right;
margin-top:-90px;
margin-left:750px;
}

.inline { 
    display: inline-block; 
    margin:10px;
    }
</style>
<br><br><br><br>
<div>
<div class="inline">
<div><br><br><br><img src="logo.png" class="logo"/></div></div>
<div class="inline">
<div class="box">
  <div class="container-1">
      <script>
  (function() {
    var cx = '016736166449918566133:9du79wrgcrq';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search></div></div></div></div>
</div>
<style>
.containerBox {
    position: relative;
    display: inline-block;
	float:left;
}
.text-box {
     color: #f2f2f2;
  font-size: 40px;
  padding: 8px 12px;
  position: absolute;
  bottom: 98px;
  width: 100%;
  text-align: center;
font-family: 'Ubuntu', Helvetica, Arial, sans-serif;
}

img.img-responsive {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

<div class="containerBox">
   
        <div class="text-box">BMI <font color="#4EFFFF">Calculator</font><br><font size="3"></font></b></font>
    </div>
    <img class="img-responsive" src="wallhaven-12018 - Copy.jpg"/>
</div>
<br><br><br>


<style>
.p1{
 color: purple;
  font-size: 40px;
   background-color:white;
max-width:850px;
    text-align: center;
margin-left:250px;
    border-top-right-radius: 15px;
box-shadow: 5px 5px 10px #888888;
    border: 0px solid green;
    padding: 10px;
font-family: 'Ubuntu', Helvetica, Arial, sans-serif;
margin-top:300px;
}
.cu1 {
  margin: auto;
   background-color:white;
max-width:850px;
    border: 0px solid green;
    padding: 10px;
   max-height: 220px;

box-shadow: 5px 5px 10px #888888;
}
.cont1 {
  margin: 0 auto;
  position: relative;
  top: 50%;
  transform: translateY(-50%);
  max-width: 750px; /* change the limit here */
color: black;
  font-size: 20px;
   
font-family: 'Vollkorn', Georgia, Times, serif;
}
.cu2 {
  margin-top:-100px;
margin-left:300px;
   background-color:white;
max-width:750px;
    border: 0px solid green;
    padding: 10px;
   max-height: 760px;
border-top-right-radius: 15px;
box-shadow: 5px 5px 10px #888888;
}
.cont2 {
  margin: 0 auto;
  position: relative;
  top: 50%;
  transform: translateY(-50%);
  max-width: 850px; /* change the limit here */
color: black;
  font-size: 20px;
   
font-family: 'Vollkorn', Georgia, Times, serif;
}
.cu3 {
  margin-top:-100px;
margin-left:400px;
   background-color:white;
width:550px;
    border: 0px solid green;
    padding: 10px;
   max-height: 100px;
border-top-right-radius: 15px;
box-shadow: 5px 5px 10px #888888;
}
.cont3 {
  margin: 0 auto;
  position: relative;
  top: 50%;
  transform: translateY(-50%);
 width: 550px; /* change the limit here */
color: black;
  font-size: 20px;
font-family: 'Vollkorn', Georgia, Times, serif;
}
.cu3_2 {
  margin-top:-100px;
margin-left:320px;
   background-color:white;
max-width:700px;
    border: 0px solid green;
    padding: 10px;
   max-height: 100px;
border-top-right-radius: 15px;
box-shadow: 5px 5px 10px #888888;
}
.cont3_2 {
  margin: 0 auto;
  position: relative;
  top: 50%;
  transform: translateY(-50%);
 max-width: 700px; /* change the limit here */
color: black;
  font-size: 20px;
font-family: 'Vollkorn', Georgia, Times, serif;
}
.cu3_3 {
  margin-top:-100px;
margin-left:320px;
   background-color:white;
max-width:700px;
    border: 0px solid green;
    padding: 10px;
   max-height:800px;
border-top-right-radius: 15px;
box-shadow: 5px 5px 10px #888888;
}

</style>

<style>
.radio {
    display: block;
    position: relative;
    padding-left: 280px;
margin-top:-50px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 16px;
 
    user-select: none;
}

/* Hide the browser's default radio button */
.radio input {
    position: absolute;
    opacity: 0;
}

/* Create a custom radio button */
.checkmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 20px;
    width: 20px;
    background-color: #eee;
border-color:purple;   
 border-radius: 80%;
margin-left:250px;
margin-top:0px;
}

/* On mouse-over, add a grey background color */
.radio:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.radio input:checked ~ .checkmark {
box-shadow: 0 0 0 2px purple;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the indicator (dot/circle) when checked */
.radio input:checked ~ .checkmark:after {
    display: block;
}

/* Style the indicator (dot/circle) */
.radio .checkmark:after {
 	top: 4px;
	left: 4px;
	width: 11px;
	height: 11px;
	border-radius: 80%;
	background: purple;
}


.textbox {
   
    border-radius: 3px;
    
    box-shadow: 0 1px 0 #FFF, 0 -2px 5px rgba(0, 0, 0, 0.08) inset;
    
    transition: all 0.5s ease;
    background: #F6F6F6;
    border: 1px solid #C8C8C8;
    color: green;
    font: 16px Helvetica, Arial, sans-serif;
    
    padding: 15px 10px 15px 40px;
    width: 200px;
height:25px;
margin-left:250px;
border-top: solid 1px #8e8e8e; 
    border-right: solid 1px #d1d1d1; 
    border-left: solid 1px #d1d1d1; 
    border-bottom: solid 1px #e4e4e4; 
    
}
 .textbox:focus {
   
    box-shadow: 0 0 2px #ED1C24 inset;
    background-color: white;
    border: 1.5px solid purple;
    outline: none;
}
.textbox:hover{
width:270px;
}
.button {
  display: inline-block;
  padding: 6px 8px;
  font-size: 15px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 6px;
  margin-left:10px;
}

.button:hover {background-color: #006600;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);

}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

</style>

<br><br><br><br><br><br><div class="p1">BMI Calculator</div>
<div class="cu1">
<div class="cont1">
<br><br><br><br><br><br><br>This calculator computes the body mass index and rates it appropriately. This calculator tells how much weight you need to gain or lose in order to achieve your goal and also provides you with the best diet plan. The SBMI - an index that has been newly developed especially for this calculator - serves for this purpose. It is based on the results of the most comprehensive study published so far on the BMI and its associated health risks. <br>Enter the following data accurately:
</div></div>

<br><br><br><br><br>
<br><br><br><div class="cu2">
<div class="cont2">
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>&nbsp;&nbsp;<font color="green" size="6">Height</font>
<form method="post" action="bmi_new.php#abc">
<label class="radio">Cm<input type="radio" name="htype" value="cm"><span class="checkmark"></span></label>
<label class="radio">M<input type="radio" name="htype" value="m" checked><span class="checkmark"></span></label>
<label class="radio">Feet<input type="radio" name="htype" value="feet"><span class="checkmark"></span></label><br>
<input placeholder="Height" id="height" class="textbox" type="text" name="height"/><font color="red">*<?php echo $herr; ?></font>



<br><br><br><br><br>&nbsp;&nbsp;<font color="green" size="6">Weight</font>
<label class="radio">Kg<input type="radio" name="wtype" value="kg" checked><span class="checkmark"></span></label>
<label class="radio">Lbs<input type="radio" name="wtype" value="lbs"><span class="checkmark"></span></label>
<br><input placeholder="Weight" id="weight" class="textbox" type="text" name="weight"/><font color="red">*<?php echo $werr;?></font>
 
<br><br><br><br><br>&nbsp;&nbsp;<font color="green" size="6">Target Weight</font>
<label class="radio">Kg<input type="radio" name="ttype" value="kg" checked><span class="checkmark"></span></label>
<label class="radio">Lbs<input type="radio" name="ttype" value="lbs"><span class="checkmark"></span></label>
<br><input placeholder="Weight" id="target" class="textbox" type="text" name="target"/><font color="red">*<?php echo $terr;?></font>
<br><br><input class="button" type="submit" name="submit2" value="Submit">
<span id="abc"></span>  
</form>
</div></div>


<br><br><br><br><br>
<br><br><br><div class="cu3" style="<?php if(!isset($_POST['submit2']) || !empty($herr) || !empty($werr) || !empty($terr)) echo 'display:none'; ?>">
<div class="cont3">
<br><br><br><p align="center" id="demo" style="color:purple; font-family:verdana;font-size:26px;"></p></div></div>

<br><br><br><br><br>
<br><br><br><div class="cu3" style="<?php if(!isset($_POST['submit2']) || !empty($herr) || !empty($werr) || !empty($terr)) echo 'display:none'; ?>">
<div class="cont3">
<br><br><br><p align="center" id="demo2" style="color:purple; font-family:verdana;font-size:26px;"></p></div></div>

<br><br><br><br><br>
<br><br><br><div class="cu3_2" style="<?php if(!isset($_POST['submit2']) || !empty($herr) || !empty($werr) || !empty($terr)) echo 'display:none'; ?>">
<div class="cont3_2">
<br><br><br><p align="center" id="demo3" style="color:purple; font-family:verdana;font-size:22px;"></p></div></div>

<br><br><br><br><br>
<br><br><br><div class="cu3_3" style="<?php if(!isset($_POST['submit2']) || !empty($herr) || !empty($werr) || !empty($terr)) echo 'display:none'; ?>">
<p align="center" id="demo4" style="color:purple; font-family:verdana;font-size:22px; position:relative;"></p></div>

<?php
if(isset($_POST['submit2']) && empty($herr) && empty($werr) && empty($terr))
{
	 $a=$_POST['height'];
     $b=$_POST['weight'];
	 $c=$_POST['target'];
	 if($_POST['htype']=="cm")
		 $a=$a/100;
	 else if($_POST['htype']=="feet")
		 $a=$a*0.3048;
	 if($_POST['wtype']=="lbs")
		 $b=$b*0.453592;
	 if($_POST['ttype']=="lbs")
		 $c=$c*0.453592;
	 $z=$b/($a*$a); ?>
	 <script>
	 var text1;
	 text1="Your BMI is: <?php echo round($z,2); ?>";
	 document.getElementById("demo").innerHTML = text1;
	 </script>
	 <?php 
	 if($z<18.5)
	 {
		 echo '
		 <script>
		 var text;
	     text = "You are Underweight  (<18.5)";
		 document.getElementById("demo2").innerHTML = text;
		 </script>
		 ';
	 }
	 else if($z>=18.5 && $z<24.9)
	 {
		 echo '
		 <script>
		 var text;
	     text = "You have Normal weight  (18.5 - 24.9)";
		 document.getElementById("demo2").innerHTML = text;
		 </script>
		 ';
	 }
	 else if($z>=24.9 && $z<29.9)
	 {
		 echo '
		 <script>
		 var text;
	     text = "You are Overweight  (24.9 - 29.9)";
		 document.getElementById("demo2").innerHTML = text;
		 </script>
		 ';
	 }
	 else
	 {
		 echo '
		 <script>
		 var text;
	     text = "You are Obese  (>30)";
		 document.getElementById("demo2").innerHTML = text;
		 </script>
		 ';
	 }
	 if($c>$b)
	 {
		 $n=(($c-$b)/$b)*100; ?>
		 <script>
		 var text4;
		 text3="You need to gain <?php echo round($n,2); ?>% weight";
		 text4="Here are some energy-dense foods that are perfect for gaining weight:<br><br>Nuts: Almonds, walnuts, macadamia nuts"+", peanuts, etc. <br><br>Dried fruit: Raisins, dates, prunes and others. <br><br>High-fat dairy: Whole milk, full-fat yogurt, cheese, cream."+
"<br><br>Fats and Oils: Extra virgin olive oil and avocado oil.<br><br>Grains: Whole grains like oats and brown rice.<br><br>Meat: Chicken, beef, pork, lamb"+", etc. Choose fattier cuts. <br><br>Tubers: Potatoes, sweet potatoes and yams.<br><br>Dark chocolate, avocados, peanut butter, coconut milk,"+" granola, trail mixes.";
          document.getElementById("demo4").innerHTML = text4;
		 </script>
	 <?php }
	 else if($c<$b)
	 {
		 $n=(($b-$c)/$b)*100; ?>
		 <script>
		 text3="You need to lose <?php echo round($n,2); ?>% weight";
		 text4="Here are the 10 most weight loss friendly foods on earth, that are supported by science.<br>1. Whole Eggs<br>2. Leafy Greens<br>3."+" Salmon<br>4. Cruciferous Vegetables<br>5. Lean Beef and "+"Chicken Breast<br>6. Boiled Potatoes<br>7. Tuna<br>8. Beans and Legumes"+"<br>9. Soups<br>10. Cottage Cheese";
         </script>
	 <?php }
	 else
	 {	?>
	 <script>
	 text3="Congrats! You currently are at your targetted weight";
	 text4="Follow your regular diet";
	 </script>
	 <?php }
	 ?>
	 <script>
	 document.getElementById("demo3").innerHTML = text3;
	 document.getElementById("demo4").innerHTML = text4;
	</script>
	<?php 
}
?>
<style>
.e{background-color:#0F9A19;
	float:center;
	color: white;
font-size: 18px;

}


.fa {
  padding: 5px;
  font-size: 23px;
  width: 30px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 70%;
}

.fa:hover {
    opacity: 0.7;
}


.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-instagram {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

</style>
<br><br><br>
<div class="e">
&nbsp&nbsp<a href="terms_new.html"><font color="white">Terms Of Use</font></a>&nbsp|&nbsp;<a href="privacy_new.html"><font color="white">Privacy Policy</font></a>
<div style="margin: 0 auto; width: 200px;">
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-instagram"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-google"></a>
<a href="#" class="fa fa-linkedin"></a></div>
<br><font size="3">Copyright 1995-2017 Medipol Pharmaceutical Company Limited. All rights reserved.</font>
</div>
</div>
</html>




