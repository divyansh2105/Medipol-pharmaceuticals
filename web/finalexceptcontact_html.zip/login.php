<?php
session_start();
?>
<html>
<body bgcolor="#EAFFEA">
<?php
if(isset($_POST['history']))
{
	header("Location:history.php");
	exit;
}
else if(isset($_POST['edit']))
{
	header("Location:edit.php");
	exit;
}
else if(isset($_POST['logout']))
{
	session_destroy(); ?>
	<script language="Javascript" type="text/javascript">
	window.top.location.href="http://localhost/new/prac2.html";
	alert("session expired");
	</script>
<?php } 
else if(!isset($_POST['edit']) && !isset($_POST['history']) && !isset($_POST['logout']))
{
	header("Location:place.php");
	exit;
}
?>
</body>
</html>
<style>
body,html
{
    padding:0px;
    margin:0px;
    height:100%;
    width:100%;
    overflow:hidden;
}
</style>