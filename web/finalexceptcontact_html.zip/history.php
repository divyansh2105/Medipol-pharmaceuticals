<?php
session_start();
$m=$_SESSION['loginuser'];
?>
<html>
<head>
<body bgcolor="#EAFFEA">
<?php
$db=mysqli_connect("localhost","root","test");
$con=mysqli_select_db($db,"pharma");
$a=mysqli_query($db,"select orderid,orderdate from orders where orgid='$m' group by orderid");
mysqli_error($db); ?>
<?php 
if(!isset($_POST['drug']))	
{ ?>
<form method="post" action="history.php" id="done">
<font size="5px">Click on Order Id to see more details:</font><br>
<table border="1">
<tr>
<td style="font-size:22px; height:60px;">Order Id</td>
<td style="font-size:22px; height:60px;">Order Date</td>
<td style="font-size:22px; height:60px;">Amount</td>
</tr>
<?php 
while($n=mysqli_fetch_array($a))
{
	$b=mysqli_query($db,"call amount10('$n[orderid]',@p,@q)");
	$c=mysqli_query($db,"select @p");
	$d=mysqli_fetch_array($c);
	mysqli_error($db);
	$i=0;
	?>

	<tr cellpadding="0px">
	<td width="300px" height="30px"><input type="submit" align="right" style="font-size:22px; width:300px; height:30px; float:left;" name="drug" value="<?php echo $n['orderid']; ?>"></td>
	<td style="font-size:22px; width:130px"><?php echo $n['orderdate']; ?></td>
	<td style="font-size:22px;" align="center"><?php echo $d['@p']; ?></td>
	</tr>
	
		<?php
	if(isset($_POST['drug'][$i]))
	{
		echo "yes";
	} ?>
	<?php //echo $n['orderid']."  ".$n['orderdate'].$d['@p']."<br>";
	$i++;
}
}
?>
</table>
</form>
<?php
if(isset($_POST['drug']))
{
	//echo $_POST['drug'];
	?>
	<div class="back"><a href="<?php echo $_SERVER['HTTP_REFERER']; ?>">Back</a></div>
	<br>
	<?php 
	$f=mysqli_query($db,"select productname,orderquantity from orders where orderid='$_POST[drug]'");
	?>
	<table border="1">
	<tr style="font-size:22px; height:60px;">
	<td>Name of Drug</td>
	<td>Quantity ordered</td>
	<td>Price</td>
	</tr>
	<?php while($n=mysqli_fetch_array($f))
	{
		$g=mysqli_query($db,"select price from drugs where productname='$n[productname]'");
		$h=mysqli_fetch_array($g);
		?>
		<tr style="font-size:22px;">
		<td><?php echo $n['productname']; ?>
		<td align="center"><?php echo $n['orderquantity']; ?>
		<td><?php echo $h['price']; ?>
		</tr>
	<?php }
}
?>
</table>
</body>
</html>
<style>
input:hover{
	cursor:pointer;
}
input{
	background-color:#EAFFEA;
	text-align:left;
	border:0px;
}
input:focus{
	border-color:red;
}
</style>
