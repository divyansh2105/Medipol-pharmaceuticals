<?php
session_start();
?>
<html>
<body bgcolor="#EAFFEA">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
 <div class="container-1">
<input type="search" name="submit1" id="search" placeholder="Search for a drug..." /></div>
</form>
<br><br><br>
<?php
	$db=mysqli_connect("localhost","root","test");
    $con=mysqli_select_db($db,"pharma");
	mysqli_error($db);
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	if(isset($_POST['submit1']))
	{
		$t=$_POST['submit1'];
		$m=mysqli_query($db,"select productname,quantity,type,price from drugs where productname like '$t%'");
$i=0;		//$d=mysqli_fetch_array($m);
if(mysqli_num_rows($m)!=0){ ?>
<br>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<table border="1">
		<tr>
		<td width="200px" style="font-size:22px; height:60px;">Name of Drug</td>
		<td width="130px" style="font-size:22px; height:60px;">Quantity</td>
		<td width="100px" style="font-size:22px; height:60px;">Price</td>
		<td width="200px" style="font-size:22px; height:60px;">Type of Drug</td>
		</tr>
		<?php while($n=mysqli_fetch_array($m))
		{ ?>
			<tr>
			<td width="200px"><label class="container"><?php echo $n['productname']; ?><input style="display:block border-radius:0 background-color:red" type="checkbox" name="drug[<?php echo $i; ?>]" value="<?php echo $n['productname']; ?>"><span class="checkmark"></span></input></td></label>
			<td width="130px" style="font-size:22px; vertical-align:top;"><input style="height:25px;" type="number" min="0" value="0" max="<?php echo $n['quantity'];?>" name="quan[<?php echo $i; ?>]"></input></td>
			<td width="100px" style="font-size:22px; vertical-align:top;"><?php echo $n['price']; ?></td>
			<td width="200px" style="font-size:22px; vertical-align:top;"><?php echo $n['type']; ?></td>
			</tr>
		<?php $i++;	} ?>
		</table>
		<br>
		<input class="button" type="submit" value="Submit" name="go"></input>
		</form>
	<?php  }
else 
{ ?>
	<div class="no">No match found</div>
<?php }
	}

if(isset($_POST['go']))
{
		$i=1;
		$time=time();
		$date=date("y-m-d");
		$id1=$_SESSION['loginuser'].$time;;
		//echo $id;
		if(!empty($_POST['drug']))
	    { ?><font size="5px">You have successfully placed order for following drugs:</font>
			<table border="1">
			<tr>
			<td width="200px" style="font-size:22px; height:60px;">Name of Drug</td>
			<td width="130px" style="font-size:22px; height:60px;">Quantity</td>
			</tr>
			<?php foreach($_POST['drug'] as $id=>$val)
		    {
				$dr=$_POST['drug'][$id];
				$qu=$_POST['quan'][$id];
				$que="INSERT INTO orders (orderid,orgid,orderdate,orderquantity,productname) VALUES('$id1','$_SESSION[loginuser]','$date','$qu','$dr')";
				$b=mysqli_query($db,$que);
				if(!$b)
				{mysqli_error($db);
				echo "yes";}
				 ?>
				<tr>
				<td style="font-size:22px;"><?php echo $_POST['drug'][$id]; ?></td>
				<td style="font-size:22px;"><?php echo $_POST['quan'][$id];?></td>
				</tr>
			<?php //echo ($i++).".)".$_POST['drug'][$id]." correspond ".$_POST["quan"][$id]."<br>";
		     }
		}
		else
			echo "No drug selected";
		//echo $_POST['quan'][5];
		//echo $_POST['drug'][1];
		?>
	<?php }
	
} ?>
</body>
</html>
<style>
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.container input {
  position: absolute;
  opacity: 0;
}
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}
.container:hover input ~ .checkmark {
  background-color: #ccc;
}
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}
.container input:checked ~ .checkmark:after {
  display: block;
}
.container .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
.container-1{
  width: 300px;
  vertical-align: middle;
  white-space: nowrap;
  position: relative;
}
.container-1 input#search{
  width: 300px;
  height: 40px;
  background: #2b303b;
  border: none;
  font-size: 15pt;
  float: left;
  color: white;
  padding-left: 45px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
}
.container-1 input#search::-webkit-input-placeholder {
   color: white;
}
 
.container-1 input#search:-moz-placeholder { /* Firefox 18- */
   color: #65737e;  
}
 
.container-1 input#search::-moz-placeholder {  /* Firefox 19+ */
   color: #65737e;  
}
 
.container-1 input#search:-ms-input-placeholder {  
   color: #65737e;  
}
.container-1 .icon{
  position: absolute;
  top: 30%;
  margin-left: 1px;
  margin-top: -10px;
  z-index: 1;
  color: white;
}
.container-1 input#search:hover, .container-1 input#search:focus, .container-1 input#search:active{
    outline:none;
    background: #9e9e9e;
  }
.button {
  display: inline-block;
  padding: 6px 8px;
  font-size: 15px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 6px;
  
}

.button:hover {background-color: #006600;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);

}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}  
</style>